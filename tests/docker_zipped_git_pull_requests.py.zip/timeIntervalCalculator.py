import datetime
import time

class TimeIntervalCalculator(object):
    def __init__(self, dateUntil, dateSince, days):
        today = datetime.datetime.today()
        if ( not (dateUntil != None and dateSince != None)) :
            if (dateUntil != None):
                # If dateUntil specified later than today
                if (dateUntil > today):
                    dateUntil = today
                # If only dateUntil is given, calculate dateSince
                dateSince = dateUntil - datetime.timedelta(days)
            elif (dateSince != None):
                # If only dateSince is given, calculate dateUntil
                dateUntil = dateSince + datetime.timedelta(days)
            else:
                # If neither dateUntil nor dateSince parameters specified,
                # set dateUntil to today,
                # set dateSince to days prior to dateUntil
                dateUntil = today
                dateSince = dateUntil - datetime.timedelta(days)
        else:
            if (dateSince > dateUntil):
                # This is an error! Raise exception.
                # Caller should handle exception appropriately
                raise ValueError('Given dateSince:{} is later than dateUntil:{}'.format(dateSince, dateUntil))
            # convert string into datetime
            dateSince = datetime.datetime.strptime(dateSince, '%Y-%m-%d')
            dateUntil = datetime.datetime.strptime(dateUntil, '%Y-%m-%d')

        # Adjust dateSince to earliest Monday within the specified time interval
        self.dateSince = self.next_weekday(dateSince,0)

        # If dateUntil specified later than today
        if (dateUntil > today):
            dateUntil = today

        # Round dateUntil to previous Sunday Midnight
        self.dateUntil = dateUntil - datetime.timedelta(days=dateUntil.weekday())

    def decrementDateSinceWeeks(self, dateSinceWeekSetback=0):
        # Decrement dateSince by dateSinceWeekSetback
        self.dateSince = self.dateSince - datetime.timedelta(weeks=dateSinceWeekSetback)

    def next_weekday(self, initialDate, weekday):
        days_ahead = weekday - initialDate.weekday()
        if days_ahead < 0: # Target day already happened this week
            days_ahead += 7
        returnDate = initialDate + datetime.timedelta(days=days_ahead)
        return returnDate

    def getDateUntil(self):
        return self.dateUntil.replace(hour=0,minute=0,second=0, microsecond=0)

    def getDateSince(self):
        return self.dateSince.replace(hour=0,minute=0,second=0, microsecond=0)

    def getDateUntilInt(self):
        return time.mktime(self.getDateUntil().timetuple())

    def getDateSinceInt(self):
        return time.mktime(self.getDateSince().timetuple())
