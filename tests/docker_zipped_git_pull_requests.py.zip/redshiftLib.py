
from __future__ import print_function
import os
import psycopg2

class RedshiftConnection(object):
    def __init__(self):
        # Defining environment variables for accessing private information
        self.E_AWS_RS_USER = os.environ['AWS_RS_USER']
        self.E_AWS_RS_PASS = os.environ['AWS_RS_PASS']
        self.DATABASE_NAME = os.environ['DATABASE_NAME']
        self.REDSHIFT_PORT = os.environ['REDSHIFT_PORT']
        self.CLUSTER_ENDPOINT = os.environ['CLUSTER_ENDPOINT']

        # Connect to the Vger Redshift DB
        self.conn = psycopg2.connect(dbname=self.DATABASE_NAME, host=self.CLUSTER_ENDPOINT, port=self.REDSHIFT_PORT,
                                     user=self.E_AWS_RS_USER, password=self.E_AWS_RS_PASS)
        self.cur = self.conn.cursor()

    def executeCommitFetchAll(self, query):
        self.cur.execute(query)
        self.conn.commit()
        queryResults = self.cur.fetchall()
        return queryResults

    def executeCommitFetchOne(self, query):
        self.cur.execute(query)
        self.conn.commit()
        queryResults = self.cur.fetchone()
        return queryResults

    def closeConnection(self):
        self.cur.close()
        self.conn.close()

    def getConn(self):
        return self.conn

    def getCursor(self):
        return self.cur

    def validateProjectID(self, projectID):
        selectIDQuery = "SELECT name, id " \
                        "FROM team_project WHERE id={}".format(projectID)
        self.cur.execute(selectIDQuery)
        self.conn.commit()
        IDResults = self.cur.fetchall()
        if not IDResults:
            raise Exception

    def statusListOfState(self, projectID, stateName):
        selectStatusQuery = "SELECT status " \
                            "FROM team_status_states " \
                            "WHERE team_project_id = {} " \
                            "AND   state_name = '{}'".format(projectID,stateName)
        self.cur.execute(selectStatusQuery)
        self.conn.commit()
        stateResults = self.cur.fetchall()
        statuses = []
        for result in stateResults:
            statuses.append(result[0])
        return statuses

    def selectRollingWindow(self, projectID):
        selectRollingWindowQuery = "SELECT rolling_time_window_days FROM team_project WHERE id={}".format(projectID)
        self.cur.execute(selectRollingWindowQuery)
        self.conn.commit()
        result = self.cur.fetchone()
        return result[0]