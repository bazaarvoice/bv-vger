from __future__ import print_function
import json
import math
import datetime

import queryParameterLib
import redshiftLib
from timeIntervalCalculator import TimeIntervalCalculator

# Returns JSON object of weekly pull requests for queried projects
# {
#   "2017-07-31 00:00:00": 5,
#   "2017-08-07 00:00:00": 2,
#   "2017-08-14 00:00:00": 3
#   ...
# }

# Query parameters
# days=90
# dateSince=2017-07-07
# dateUntil=2017-10-05
# repoName=comma,separated,values OR empty string for all repositories

def handler(event, context):
    # Verify that url path contains project id
    try: 
        project_id = (event.get('pathParameters').get('id'))
    except Exception as e:
        print(e)
        payload = {'message': 'Project id not found in url spath'}
        response = {
            'statusCode': 400,
            'headers': {
                'Access-Control-Allow-Origin' : '*',
                'Access-Control-Allow-Credentials' : True
            },
            'body': json.dumps(payload)
        }
        return response

    # Verify that query parameters are valid
    try:
        query_parameters = queryParameterLib.QueryParameters(event)
        
        # Count throughput of all repositories by default if not specified
        all_repos = True
        if query_parameters.getRepoName() is not None and query_parameters.getRepoName() != '':
            # Prepare strings for query
            repo_list = query_parameters.getRepoName().split(',')
            repo_names = ', '.join("'{}'".format(repo) for repo in repo_list)
            all_repos = False
            
        date_until = query_parameters.getDate('dateUntil')
        date_since = query_parameters.getDate('dateSince')
        days = query_parameters.getDays()
    except ValueError as e:
        print (e)
        payload = {'message': 'Invalid query parameters'}
        response = {
            'statusCode': 400,
            'headers': {
                'Access-Control-Allow-Origin' : '*',
                'Access-Control-Allow-Credentials' : True
            },
            'body': json.dumps(payload)
        }
        return response

    # Open connection to Redshift 
    redshift = redshiftLib.RedshiftConnection()

    # Prepare time interval for counting pull requests by week
    rolling_window_days = redshift.selectRollingWindow(project_id)
    rolling_window_weeks = int(math.floor(rolling_window_days/7.0))
    time_interval = TimeIntervalCalculator(date_until, date_since, days)
    
    # Find the very first monday in the date range
    initial_week = time_interval.getDateSince()

    # Initial PR throughput object that will be returned as JSON if handler succeeds
    pr_throughput = {}
    # Initialize starting week
    curr_week = initial_week
    # Count weekly pull requests
    for i in range(rolling_window_weeks):
        next_week = curr_week + datetime.timedelta(weeks=1)
        # Fetch pull request count per given week
        pr_count_query = """
        SELECT COUNT(*)
        FROM pull_requests
        WHERE created_at >= '{}'
        AND closed_at <= '{}'
        """.format(str(curr_week), str(next_week))

        if not all_repos:
            pr_count_query += 'AND repo in ({})'.format(repo_names)

        try: 
            pr_count = redshift.executeCommitFetchOne(pr_count_query)[0]
            pr_throughput[str(curr_week)] = int(pr_count)

        except Exception as e:
            print('Failed query {} with {}'.format(pr_count_query, e))
            redshift.closeConnection()
            payload = { 'message': 'Internal error' }
            response = {
                'statusCode': 500,
                'headers': {
                    'Access-Control-Allow-Origin' : '*', # Required for CORS support to work
                    'Access-Control-Allow-Credentials' : True # Required for cookies, authorization headers with HTTPS
                },
                'body': json.dumps(payload)
            }
            return response
        curr_week = next_week

    # Close connection to Redshift
    redshift.closeConnection()

    # Lambda must return a response
    response = {
        'statusCode': 200,
        'headers': {
            'Access-Control-Allow-Origin' : '*', # Required for CORS support to work
            'Access-Control-Allow-Credentials' : True # Required for cookies, authorization headers with HTTPS
        },
        'body': json.dumps(pr_throughput)
    }
    return response